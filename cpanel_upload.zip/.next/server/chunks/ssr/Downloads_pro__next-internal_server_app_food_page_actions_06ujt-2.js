module.exports=[14733,(a,b,c)=>{}];

//# sourceMappingURL=Downloads_pro__next-internal_server_app_food_page_actions_06ujt-2.js.map