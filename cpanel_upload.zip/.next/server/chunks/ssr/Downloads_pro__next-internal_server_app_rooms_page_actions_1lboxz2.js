module.exports=[69037,(a,b,c)=>{}];

//# sourceMappingURL=Downloads_pro__next-internal_server_app_rooms_page_actions_1lboxz2.js.map