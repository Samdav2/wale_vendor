module.exports=[95369,(a,b,c)=>{}];

//# sourceMappingURL=Downloads_pro__next-internal_server_app_page_actions_1t0pxxl.js.map