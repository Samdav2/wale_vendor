module.exports=[94365,(a,b,c)=>{}];

//# sourceMappingURL=Downloads_pro__next-internal_server_app_staff_new_page_actions_1nvclwk.js.map