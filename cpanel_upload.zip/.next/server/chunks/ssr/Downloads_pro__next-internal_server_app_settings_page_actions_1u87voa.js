module.exports=[14387,(a,b,c)=>{}];

//# sourceMappingURL=Downloads_pro__next-internal_server_app_settings_page_actions_1u87voa.js.map