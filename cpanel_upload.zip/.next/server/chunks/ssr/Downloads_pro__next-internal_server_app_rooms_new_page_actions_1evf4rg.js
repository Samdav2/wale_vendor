module.exports=[22969,(a,b,c)=>{}];

//# sourceMappingURL=Downloads_pro__next-internal_server_app_rooms_new_page_actions_1evf4rg.js.map