module.exports=[18509,(a,b,c)=>{}];

//# sourceMappingURL=Downloads_pro__next-internal_server_app_food_new_page_actions_1gfgz3-.js.map