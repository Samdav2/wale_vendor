module.exports=[32179,(a,b,c)=>{}];

//# sourceMappingURL=Downloads_pro__next-internal_server_app__not-found_page_actions_1h6dyn4.js.map