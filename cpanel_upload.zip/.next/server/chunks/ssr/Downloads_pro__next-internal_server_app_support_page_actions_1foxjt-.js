module.exports=[42303,(a,b,c)=>{}];

//# sourceMappingURL=Downloads_pro__next-internal_server_app_support_page_actions_1foxjt-.js.map