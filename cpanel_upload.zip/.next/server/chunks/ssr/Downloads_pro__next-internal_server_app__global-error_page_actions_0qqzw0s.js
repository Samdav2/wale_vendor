module.exports=[59457,(a,b,c)=>{}];

//# sourceMappingURL=Downloads_pro__next-internal_server_app__global-error_page_actions_0qqzw0s.js.map