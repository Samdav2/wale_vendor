globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/sCZ_fdCdn3nvKD7mZ0iVv/_buildManifest.js",
    "static/sCZ_fdCdn3nvKD7mZ0iVv/_ssgManifest.js",
    "static/sCZ_fdCdn3nvKD7mZ0iVv/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0kc6woapi2k4l.js",
    "static/chunks/3-feu8znnm60d.js",
    "static/chunks/3pz_1y5dpqwy3.js",
    "static/chunks/0px-rfeycslgu.js",
    "static/chunks/turbopack-1ziu1im2dczxl.js"
  ]
};
