var R=require("../../chunks/ssr/[turbopack]_runtime.js")("server/app/_global-error/page.js")
R.c("server/chunks/ssr/[root-of-the-server]__0yn4q7a._.js")
R.c("server/chunks/ssr/1-iz_next_dist_esm_build_templates_app-page_0fgx3e1.js")
R.c("server/chunks/ssr/[root-of-the-server]__1e1mwt2._.js")
R.c("server/chunks/ssr/[root-of-the-server]__1tftza7._.js")
R.c("server/chunks/ssr/1-iz_next_dist_client_components_builtin_global-error_0dvsoyy.js")
R.c("server/chunks/ssr/Downloads_pro__next-internal_server_app__global-error_page_actions_0qqzw0s.js")
R.m(19668)
module.exports=R.m(19668).exports
