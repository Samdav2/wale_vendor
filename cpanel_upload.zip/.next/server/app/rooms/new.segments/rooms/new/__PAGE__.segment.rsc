1:"$Sreact.fragment"
2:I[14940,["/_next/static/chunks/0z689rgv9o133.js","/_next/static/chunks/3qfuyqwwf8o21.js","/_next/static/chunks/44_t-s_2h71x3.js"],"default"]
3:I[31377,["/_next/static/chunks/0z689rgv9o133.js","/_next/static/chunks/3qfuyqwwf8o21.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","$L2",null,{}],[["$","script","script-0",{"src":"/_next/static/chunks/44_t-s_2h71x3.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"sCZ_fdCdn3nvKD7mZ0iVv"}
5:null
