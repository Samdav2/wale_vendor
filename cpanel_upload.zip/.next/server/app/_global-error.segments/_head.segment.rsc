1:"$Sreact.fragment"
2:I[31377,["/_next/static/chunks/1ut6rrhav0xco.js","/_next/static/chunks/3qfuyqwwf8o21.js"],"ViewportBoundary"]
3:I[31377,["/_next/static/chunks/1ut6rrhav0xco.js","/_next/static/chunks/3qfuyqwwf8o21.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[]}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"sCZ_fdCdn3nvKD7mZ0iVv"}
