1:"$Sreact.fragment"
2:I[2454,["/_next/static/chunks/0z689rgv9o133.js","/_next/static/chunks/3qfuyqwwf8o21.js"],"default"]
3:I[42165,["/_next/static/chunks/0z689rgv9o133.js","/_next/static/chunks/3qfuyqwwf8o21.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"sCZ_fdCdn3nvKD7mZ0iVv"}
