1:"$Sreact.fragment"
2:I[31377,["/_next/static/chunks/0z689rgv9o133.js","/_next/static/chunks/3qfuyqwwf8o21.js"],"ViewportBoundary"]
3:I[31377,["/_next/static/chunks/0z689rgv9o133.js","/_next/static/chunks/3qfuyqwwf8o21.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
5:I[12202,["/_next/static/chunks/0z689rgv9o133.js","/_next/static/chunks/3qfuyqwwf8o21.js"],"IconMark"]
0:{"rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"Ghungroo Wale Dashboard"}],["$","meta","1",{"name":"description","content":"Modern Property Management System built with Next.js, Tailwind CSS and TypeScript"}],["$","link","2",{"rel":"icon","href":"/icon.png?icon.38so1qnsvt1ot.png","sizes":"400x400","type":"image/png"}],["$","$L5","3",{}]]}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"sCZ_fdCdn3nvKD7mZ0iVv"}
