var R=require("../../chunks/[turbopack]_runtime.js")("server/app/icon.png/route.js")
R.c("server/chunks/[externals]_next_dist_0iuj5m_._.js")
R.c("server/chunks/[root-of-the-server]__1hjg7fx._.js")
R.c("server/chunks/Downloads_pro__next-internal_server_app_icon_png_route_actions_1zep0c6.js")
R.m(97911)
module.exports=R.m(97911).exports
